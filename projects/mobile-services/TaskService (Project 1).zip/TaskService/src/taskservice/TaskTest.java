package taskservice;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
	
	@Test
	public void testValidTaskCreation() {
		
		Task task = new Task(
				"123",
				"Task Name",
				"Task Description"
		);
		
		assertEquals("123", task.getTaskId());
		assertEquals("Task Name", task.getName());
		assertEquals("Task Description", task.getDescription());
	}
	
	@Test
	public void testUpdateTaskDescription() {
		
        Task task = new Task(
                "123",
                "Task",
                "Description"
                );

                task.setDescription("Updated Description");

                assertEquals("Updated Description", task.getDescription());
            }
	
	@Test
	public void testNullTaskId() {

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> new Task(
	                    null,
	                    "Task Name",
	                    "Task Description"));
	}

	@Test
	public void testLongTaskId() {

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> new Task(
	                    "12345678901",
	                    "Task Name",
	                    "Task Description"));
	}

	@Test
	public void testNullName() {

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> new Task(
	                    "123",
	                    null,
	                    "Task Description"));
	}

	@Test
	public void testLongName() {

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> new Task(
	                    "123",
	                    "ThisTaskNameIsWayTooLong",
	                    "Task Description"));
	}

	@Test
	public void testNullDescription() {

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> new Task(
	                    "123",
	                    "Task Name",
	                    null));
	}

	@Test
	public void testLongDescription() {

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> new Task(
	                    "123",
	                    "Task Name",
	                    "This description is intentionally made longer than fifty characters to fail."));
	}

	@Test
	public void testUpdateTaskName() {

	    Task task = new Task(
	            "123",
	            "Old Name",
	            "Description");

	    task.setName("New Name");

	    assertEquals(
	            "New Name",
	            task.getName());
	}

	@Test
	public void testInvalidNameUpdate() {

	    Task task = new Task(
	            "123",
	            "Task Name",
	            "Description");

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> task.setName(
	                    "ThisTaskNameIsWayTooLong"));
	}

	@Test
	public void testInvalidDescriptionUpdate() {

	    Task task = new Task(
	            "123",
	            "Task Name",
	            "Description");

	    assertThrows(
	            IllegalArgumentException.class,
	            () -> task.setDescription(
	                    "This description is intentionally made longer than fifty characters to fail."));
	}
}