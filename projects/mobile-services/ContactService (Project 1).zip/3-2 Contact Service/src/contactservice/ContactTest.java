package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContact() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        assertEquals("12345", contact.getContactId());
    }
    
    @Test
    public void testLongContactId() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345678901",
                        "John",
                        "Doe",
                        "1234567890",
                        "123 Main Street"));
    }
    
    @Test
    public void testLongFirstName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345",
                        "VeryLongName",
                        "Doe",
                        "1234567890",
                        "123 Main Street"));
    }
    
    @Test
    public void testLongLastName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345",
                        "John",
                        "VeryLongLastName",
                        "1234567890",
                        "123 Main Street"));
    }
    
    @Test
    public void testLongAddress() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345",
                        "John",
                        "Doe",
                        "1234567890",
                        "1234567890123456789012345678901"));
    }

    @Test
    public void testNullContactId() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        null,
                        "John",
                        "Doe",
                        "1234567890",
                        "123 Main Street"));
    }

    @Test
    public void testNullFirstName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345",
                        null,
                        "Doe",
                        "1234567890",
                        "123 Main Street"));
    }

    @Test
    public void testNullLastName() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345",
                        "John",
                        null,
                        "1234567890",
                        "123 Main Street"));
    }

    @Test
    public void testNullPhone() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345",
                        "John",
                        "Doe",
                        null,
                        "123 Main Street"));
    }

    @Test
    public void testNullAddress() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345",
                        "John",
                        "Doe",
                        "1234567890",
                        null));
    }
    
    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        contact.setFirstName("Jane");

        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        contact.setLastName("Smith");

        assertEquals("Smith", contact.getLastName());
    }
    
    @Test
    public void testUpdatePhone() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        contact.setPhone("0987654321");

        assertEquals("0987654321", contact.getPhone());
    }
    
    @Test
    public void testUpdateAddress() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        contact.setAddress("456 Oak Avenue");

        assertEquals(
                "456 Oak Avenue",
                contact.getAddress());
    }

    @Test
    public void testInvalidPhone() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        assertThrows(
                IllegalArgumentException.class,
                () -> contact.setPhone("123"));
    }
    
    @Test
    public void testInvalidFirstName() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        assertThrows(
                IllegalArgumentException.class,
                () -> contact.setFirstName("VeryLongName"));
    }
    
    @Test
    public void testInvalidLastName() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        assertThrows(
                IllegalArgumentException.class,
                () -> contact.setLastName("VeryLongLastName"));
    }
    
    @Test
    public void testInvalidAddress() {
        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        assertThrows(
                IllegalArgumentException.class,
                () -> contact.setAddress(
                        "1234567890123456789012345678901"));
    }

}