package appointmentservice;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment("A123",
                        new Date(System.currentTimeMillis() + 86400000),
                        "Checkup");

        service.addAppointment(appointment);

        assertEquals(appointment,
                service.getAppointment("A123"));
    }

    @Test
    public void testDuplicateAppointmentId() {
        AppointmentService service = new AppointmentService();

        Appointment appointment1 =
                new Appointment("A123",
                        new Date(System.currentTimeMillis() + 86400000),
                        "Checkup");

        Appointment appointment2 =
                new Appointment("A123",
                        new Date(System.currentTimeMillis() + 172800000),
                        "Dentist");

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class,
                () -> service.addAppointment(appointment2));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment("A123",
                        new Date(System.currentTimeMillis() + 86400000),
                        "Checkup");

        service.addAppointment(appointment);
        service.deleteAppointment("A123");

        assertNull(service.getAppointment("A123"));
    }
    
    @Test
    public void testDeleteMissingAppointment() {
        AppointmentService service = new AppointmentService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteAppointment("A123"));
    }
}