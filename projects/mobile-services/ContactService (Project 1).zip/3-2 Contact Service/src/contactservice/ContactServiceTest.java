package contactservice;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    public void testDuplicateContactId() {

        ContactService service = new ContactService();

        Contact contact1 = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        Contact contact2 = new Contact(
                "12345",
                "Jane",
                "Smith",
                "0987654321",
                "456 Oak Street");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);
        service.deleteContact("12345");

        assertNull(service.getContact("12345"));
    }

    @Test
    public void testUpdatePhone() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updatePhone("12345", "1112223333");

        assertEquals("1112223333",
                service.getContact("12345").getPhone());
    }
    
    @Test
    public void testUpdateFirstName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updateFirstName("12345", "Jane");

        assertEquals(
                "Jane",
                service.getContact("12345").getFirstName());
    }
    
    @Test
    public void testUpdateFirstNameMissingContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99999", "Jane");
        });
    }

    @Test
    public void testUpdateLastName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updateLastName("12345", "Smith");

        assertEquals(
                "Smith",
                service.getContact("12345").getLastName());
    }
    
    @Test
    public void testUpdateLastNameMissingContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateLastName("99999", "Smith");
        });
    }

    @Test
    public void testUpdateAddress() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "12345",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        service.addContact(contact);

        service.updateAddress(
                "12345",
                "456 Oak Street");

        assertEquals(
                "456 Oak Street",
                service.getContact("12345").getAddress());
    }
    
    @Test
    public void testUpdateAddressMissingContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAddress("99999", "456 Oak Street");
        });
    }
    
    @Test
    public void testDeleteMissingContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("99999");
        });
    }
    
    @Test
    public void testUpdatePhoneMissingContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("99999", "1112223333");
        });
    }
}
