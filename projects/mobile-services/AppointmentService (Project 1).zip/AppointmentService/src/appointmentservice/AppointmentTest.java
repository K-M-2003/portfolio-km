package appointmentservice;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment =
                new Appointment("A123", futureDate, "Doctor Visit");

        assertEquals("A123", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor Visit", appointment.getDescription());
    }

    @Test
    public void testNullId() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment(null, futureDate, "Test"));
    }

    @Test
    public void testLongId() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("12345678901", futureDate, "Test"));
    }

    @Test
    public void testPastDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", pastDate, "Test"));
    }

    @Test
    public void testNullDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A123", futureDate, null));
    }
    
    @Test
    public void testNullDate() {

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "A123",
                        null,
                        "Doctor Visit"));
    }

    @Test
    public void testLongDescription() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 86400000);

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "A123",
                        futureDate,
                        "This description is intentionally longer than fifty characters and should fail."));
    }
    
}