package taskservice;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    public void testAddTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "123",
                "Task",
                "Description"
        );

        service.addTask(task);

        assertEquals(task, service.getTask("123"));
    }

    @Test
    public void testAddDuplicateTaskId() {

        TaskService service = new TaskService();

        Task task1 = new Task(
                "123",
                "Task1",
                "Description1"
        );

        Task task2 = new Task(
                "123",
                "Task2",
                "Description2"
        );

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "123",
                "Task",
                "Description"
        );

        service.addTask(task);
        service.deleteTask("123");

        assertNull(service.getTask("123"));
    }
    
    @Test
    public void testDeleteMissingTask() {

        TaskService service = new TaskService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteTask("999"));
    }

    @Test
    public void testUpdateTaskName() {

        TaskService service = new TaskService();

        Task task = new Task(
                "123",
                "Task",
                "Description"
        );

        service.addTask(task);

        service.updateTaskName("123", "Updated Name");

        assertEquals(
                "Updated Name",
                service.getTask("123").getName()
        );
    }
    
    @Test
    public void testUpdateTaskNameMissingTask() {

        TaskService service = new TaskService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateTaskName(
                        "999",
                        "Updated Name"));
    }

    @Test
    public void testUpdateTaskDescription() {

        TaskService service = new TaskService();

        Task task = new Task(
                "123",
                "Task",
                "Description"
        );

        service.addTask(task);

        service.updateTaskDescription(
                "123",
                "Updated Description"
        );

        assertEquals(
                "Updated Description",
                service.getTask("123").getDescription()
        );
    }
    
    @Test
    public void testUpdateTaskDescriptionMissingTask() {

        TaskService service = new TaskService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateTaskDescription(
                        "999",
                        "Updated Description"));
    }
}